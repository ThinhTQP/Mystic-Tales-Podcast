import type { IconInput, MathInput, StringInput } from "./input";

/* ------------------------------- */
/* KHAI BÁO INTERFACE CHO QUESTIONS */
/* ------------------------------- */

// BASIC QUESTION INTERFACE
export interface Question {
  Id: number;
  QuestionTypeId: 1 | 2 | 3 | 4 | 5 | 6 | 7;
  Content: string;
  Description: string;
  Order: number;
  IsVoiced: boolean;
  TimeLimit: number;
  ConfigJson: Record<string, unknown>;
  Options: QuestionOption[];
}
// Khai báo Options
export interface QuestionOption {
  Id: string;
  Content: string;
  Order: number;
  Value: any;
}
// Key cho option content (theo index)
export type OptionContentKey = `Options[${number}].Content`;

// -------------------------------------------------------------- //
// SINGLE CHOICE QUESTION TYPE INTERFACE
export interface SingleChoiceQuestion extends Question {
  QuestionTypeId: 1;
  ConfigJson: {};
  Mutable: SingleChoiceMutableMap;
}
export type SingleChoiceMutableBase = {
  Content: StringInput;
  Description: StringInput;
};

export type SingleChoiceMutableMap = SingleChoiceMutableBase &
  Partial<Record<OptionContentKey, StringInput>>;
// -------------------------------------------------------------- //

// MULTIPLE CHOICE QUESTION TYPE INTERFACE
export interface MultipleChoiceQuestion extends Question {
  QuestionTypeId: 2;
  ConfigJson: {
    MinChoiceCount: number;
    MaxChoiceCount: number;
  };
  Mutable: MultipleChoiceMutableMap;
}
export type MultipleChoiceMutableBase = {
  Content: StringInput;
  Description: StringInput;
  "ConfigJson.MinChoiceCount": MathInput;
  "ConfigJson.MaxChoiceCount": MathInput;
};
export type MultipleChoiceMutableMap = MultipleChoiceMutableBase &
  Partial<Record<OptionContentKey, StringInput>>;
// -------------------------------------------------------------- //

// SINGLE SLIDER QUESTION TYPE INTERFACE
export interface SingleSliderQuestion extends Question {
  QuestionTypeId: 3;
  ConfigJson: {
    Min: number;
    Max: number;
    Step: number;
    Unit: string;
  };
  Mutable: {
    Content: StringInput;
    Description: StringInput;
    "ConfigJson.Min": MathInput;
    "ConfigJson.Max": MathInput;
    "ConfigJson.Step": MathInput;
    "ConfigJson.Unit": StringInput;
  };
}
// -------------------------------------------------------------- //

// RANGE SLIDER QUESTION TYPE INTERFACE
export interface RangeSliderQuestion extends Question {
  QuestionTypeId: 4;
  ConfigJson: {
    Min: number;
    Max: number;
    Step: number;
    Unit: string;
  };
  Mutable: {
    Content: StringInput;
    Description: StringInput;
    "ConfigJson.Min": MathInput;
    "ConfigJson.Max": MathInput;
    "ConfigJson.Step": MathInput;
    "ConfigJson.Unit": StringInput;
  };
}
// -------------------------------------------------------------- //

// SINGLE INPUT QUESTION TYPE INTERFACE
export interface SingleInputQuestion extends Question {
  QuestionTypeId: 5;
  ConfigJson: {
    FieldInputTypeId: number;
  };
  Mutable: {
    Content: StringInput;
    Description: StringInput;
  };
}
// -------------------------------------------------------------- //

// RATING QUESTION TYPE INTERFACE
export interface RatingQuestion extends Question {
  QuestionTypeId: 6;
  ConfigJson: {
    RatingLength: number;
    RatingIcon: string;
  };
  Mutatble: {
    Content: StringInput;
    Description: StringInput;
    RatingLength: MathInput;
    RatingIcon: IconInput;
  };
}
// -------------------------------------------------------------- //

// RANKING QUESTION TYPE INTERFACE
export interface RankingQuestion extends Question {
  QuestionTypeId: 7;
  ConfigJson: {};
  Mutable: RankingMutableMap;
}
export type RankingMutableBase = {
  Content: StringInput;
  Description: StringInput;
};

export type RankingMutableMap = RankingMutableBase &
  Partial<Record<OptionContentKey, StringInput>>;

// ------ COMBINE TYPE ------- //
export type QuestionType =
  | SingleChoiceQuestion
  | MultipleChoiceQuestion
  | SingleSliderQuestion
  | RangeSliderQuestion
  | SingleInputQuestion
  | RatingQuestion
  | RankingQuestion;
