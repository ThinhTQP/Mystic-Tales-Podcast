// ĐÂY LÀ TRANG ĐỂ VÍ DỤ CHO CÁC INTERFACE ĐÃ KHAI BÁO

import type {
  ConditionBlock,
  EndBlock,
  ForEachBlock,
  InitVariableBlock,
  RenderQuestionBlock,
  SetVariableBlock,
  StartBlock,
} from "@/types/block";
import type {
  ArrayInput,
  ArrayRefValue,
  BooleanArrayInput,
  BooleanInput,
  IconInput,
  MathInput,
  NumberArrayInput,
  ObjectArrayInput,
  ObjectInput,
  StringArrayInput,
  StringInput,
} from "@/types/input";
import type {
  MultipleChoiceQuestion,
  RangeSliderQuestion,
  RankingQuestion,
  RatingQuestion,
  SingleChoiceQuestion,
  SingleInputQuestion,
  SingleSliderQuestion,
} from "@/types/question";

// RULE ĐỂ LẤY GIÁ TRỊ TỪ PREVIOUS DATA:
/*
- Đối với các giá trị có kiểu primitive (nguyên thủy): path = value
-- Example: a = 5 => path = "value";

- Đối với các giá trị có kiểu object: 
-- Example: 
    user = {
      name: "Hoàng Minh Lộc",
      age: 21,
      isMale: true,
    }
  + Muốn lấy nguyên object user => path = "value"
  + Muốn lấy user.name => path = "value.name.value"
  + Muốn lấy user.age => path = "value.age.value"
  + Muốn lấy user.isMale => path = "value.isMale.value"

- Đối với các giá trị có kiểu array:
-- Example: 
   favoriteProducts = ["Laptop", "Iphone", "Pizza"]
  + Muốn lấy nguyên array favoriteProducts => path = "value"
  + Muốn lấy phần tử có index: 0 => path = "value.[0].value"

- Đối với CÂU HỎI TRƯỚC ĐÓ:
-- Example:
   Câu 1: Bạn đã xài bao nhiêu tiền tháng trước ?
    Min: 0, Max: 100000, Step: 1, Unit: "VND", Taken: 500
  + Muốn lấy giá trị đã chọn => path = "taken.value"
  + Muốn lấy Min => "default.ConfigJson.Min.value"
  + Muốn lấy Step => "default.ConfigJson.Step.value"

   Câu 2: Bạn có thích sản phẩm không ?
    A. Có (value = true) (Order = 1)
    B. Không (value = false) (Order = 2)
    => Chọn B
  + Muốn lấy giá trị đã chọn => path = "taken.value"
  + Muốn lấy giá trị của option A (Order = 1) => path = "default.option.[1].value"
  + Muốn lấy content của option B (Order = 2) => path = "default.option.[2].Content"
  + Muốn lấy content của câu hỏi => path = "default.Content"

   Câu 3: Xếp hạng các món ăn bạn thích nhất
    A. Bún Đậu 
    B. Pizza
    C. Phở
    D. Cơm Tấm
    => Rank: Cơm Tấm > Phở > Bún Đậu > Pizza (1 - 4)
  + Muốn lấy giá trị của option có rank 1 => path = "taken.rank.[1].value" = Cơm Tấm
  + Muốn lấy giá trị của option có rank 2 => path = "taken.rank.[2].value" = Phở  

- Khi gán biến, hoặc thao tác. Cần đảm bảo type lấy ra match. Này là rule tự validate
*/

// ---------------------------------------------------------------
// ---------------------------------------------------------------
// I/ EXAMPLE CHO CÁC INPUT INTERFACE
// ---------------------------------------------------------------
// ---------------------------------------------------------------

// 1.1/ String Input:

// String nhập tay:
const stringInput1: StringInput = {
  Id: "string-input-1",
  Type: "string",
  Value: {
    default: "",
    template: "Đây là đoạn string nhập tay được lưu từ bàn phím",
    placeHolders: [], //Place Holders để trống vì không có thay đổi gì
  },
};

// String nhận vào DYNAMIC VALUE từ BIẾN
const stringInput2: StringInput = {
  Id: "string-input-2",
  Type: "string",
  Value: {
    default: "Đây là fallback khi không lấy được biến",
    template: "Chào ${fullName}, bạn đã mua bao nhiêu sản phẩm rồi?",
    placeHolders: [
      {
        name: "fullName", //Tên của placeholder được dùng
        dataType: "string", //Kiểu ban đầu của dữ liệu. Sau đó được parse về string
        description:
          "Đây là biến fullName được lấy từ attribute name của biến object user",
        source: {
          kind: "ref",
          ref: {
            kind: "var", //Dùng biến thì là var
            varName: "user", //Tên biến tham chiếu tới
            blockPath: "001.001",
            path: "value.name.value", //Attribute trỏ tới
          },
        },
      },
    ],
  },
};

// String nhận vào DYNAMIC VALUE từ CÂU TRƯỚC ĐÓ
const stringInput3: StringInput = {
  Id: "string-input-3",
  Type: "string",
  Value: {
    default: "Đây là fallback khi không lấy được giá trị",
    template: "Bạn đã mua ${selectedOption} sản phẩm đúng không ?",
    placeHolders: [
      {
        name: "selectedOption", //Tên của placeholder được dùng
        dataType: "number", //Kiểu ban đầu của dữ liệu. Sau đó được parse về string
        description: "Đây là giá trị được kéo ở câu dạng slider trước đó",
        source: {
          kind: "ref",
          ref: {
            kind: "question", //Dùng câu trước thì là question
            blockPath: "001.001.001",
            path: "taken.value", //Gía trị đã chọn
          },
        },
      },
    ],
  },
};

// 1.2/ Math Input:

// Math được nhập thẳng từ bàn phím
const mathInput1: MathInput = {
  Id: "math-input-1",
  Type: "math",
  Value: 10, //Giá trị nhập thẳng từ bàn phím
};

// Math được tham chiếu thẳng từ BIẾN
const mathInput2: MathInput = {
  Id: "math-input-2",
  Type: "math",
  Value: {
    kind: "ref",
    ref: {
      kind: "var",
      varName: "user",
      blockPath: "001",
      path: "value.age.value",
    },
  },
};

// Math được tham chiếu từ giá trị của CÂU TRƯỚC ĐÓ
const mathInput3: MathInput = {
  Id: "math-input-3",
  Type: "math",
  Value: {
    kind: "ref",
    ref: {
      kind: "question",
      placeHolder: "numOfBoughtProducts", //Đặt placeholder cho giá trị đó
      blockPath: "001.001.001",
      path: "taken.value", //ĐẢM BẢO VALUE PHẢI LÀ NUMBER
    },
  },
};

// Math là 1 công thức đơn giản
// mathInput4 = [(5 + 3) * 2]^3 = 4096
const mathInput4: MathInput = {
  Id: "math-input-4",
  Type: "math",
  Value: {
    kind: "expr",
    expr: {
      node: "binary",
      op: "^",
      left: {
        node: "binary",
        op: "*",
        left: {
          node: "binary",
          op: "+",
          left: {
            node: "const",
            value: 5,
          },
          right: {
            node: "const",
            value: 3,
          },
        },
        right: {
          node: "const",
          value: 2,
        },
      },
      right: {
        node: "const",
        value: 3,
      },
    },
    calculatedValue: 4096, //Giá trị được tính ra sẵn nếu như các phần tử bên trong không có sử dụng previous-data
  },
};

// Math là 1 công thức phức tạp, có sử dụng previous-data bên trong
// mathInput5 = P * r * {[(1 + r) ^ months]/[(1 + months) ^ months - 1] }
// Với:
// - P: BIẾN Number tham chiếu từ Block 001.001.001
// - r: BIẾN Number tham chiếu từ Block 001.001.001.001.001
// - months: GIÁ TRỊ Number tham chiếu từ Câu Trước Đó 001.001.001.001.001.001
const mathInput5: MathInput = {
  Id: "math-input-005",
  Type: "math",
  Value: {
    kind: "expr",
    expr: {
      node: "binary",
      op: "*",
      left: {
        node: "ref",
        ref: {
          kind: "var",
          varName: "P",
          blockPath: "001.001.001",
          path: "value",
        },
      },
      right: {
        node: "binary",
        op: "*",
        left: {
          node: "ref",
          ref: {
            kind: "var",
            varName: "r",
            blockPath: "001.001.001.001.001",
            path: "value",
          },
        },
        right: {
          node: "binary",
          op: "/",
          left: {
            node: "binary",
            op: "^",
            left: {
              node: "binary",
              op: "+",
              left: {
                node: "const",
                value: 1,
              },
              right: {
                node: "ref",
                ref: {
                  kind: "var",
                  varName: "r",
                  blockPath: "001.001.001.001.001",
                  path: "value",
                },
              },
            },
            right: {
              node: "ref",
              ref: {
                kind: "question",
                placeHolder: "months",
                blockPath: "001.001.001.001.001.001",
                path: "taken.value",
              },
            },
          },
          right: {
            node: "binary",
            op: "-",
            left: {
              node: "binary",
              op: "^",
              left: {
                node: "binary",
                op: "+",
                left: {
                  node: "const",
                  value: 1,
                },
                right: {
                  node: "ref",
                  ref: {
                    kind: "var",
                    varName: "r",
                    blockPath: "001.001.001.001.001",
                    path: "value",
                  },
                },
              },
              right: {
                node: "ref",
                ref: {
                  kind: "question",
                  placeHolder: "months",
                  blockPath: "001.001.001.001.001.001",
                  path: "taken.value",
                },
              },
            },
            right: {
              node: "const",
              value: 1,
            },
          },
        },
      },
    },
  },
};

// 1.3/ Boolean Input:

// Boolean được nhập thẳng từ bàn phím:
const booleanInput1: BooleanInput = {
  Id: "boolean-input-1",
  Type: "boolean",
  Value: false,
};

// Boolean được tham chiếu từ BIÊN
const booleanInput2: BooleanInput = {
  Id: "boolean-input-2",
  Type: "boolean",
  Value: {
    kind: "ref",
    ref: {
      kind: "var",
      varName: "isMale",
      blockPath: "001.001.002",
      path: "value", //Đảm bảo value ở đây là Boolean
    },
  },
};

// Boolean được tham chiếu từ CÂU TRƯỚC ĐÓ
const booleanInput3: BooleanInput = {
  Id: "boolean-input-3",
  Type: "boolean",
  Value: {
    kind: "ref",
    ref: {
      kind: "question",
      blockPath: "001.001",
      path: "taken.value", //Đảm bảo value ở đây là Boolean
    },
  },
};

// 1.4/ Object Input

// Object nhập thẳng từ bàn phím
// const objectInput1 = {name: "Hoàng Minh Lộc", age: 21, isMale: true}
const objectInput1: ObjectInput = {
  Id: "object-input-1",
  Type: "object",
  Value: {
    name: {
      Id: "string-attribute-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "Hoàng Minh Lộc",
        placeHolders: [],
      },
    } as StringInput,
    age: {
      Id: "math-attribute-input-1",
      Type: "math",
      Value: 21,
    } as MathInput,
    isMale: {
      Id: "boolean-attribute-input-1",
      Type: "boolean",
      Value: true,
    } as BooleanInput,
  },
};

// Object tham chiếu tới BIẾN
const objectInput2: ObjectInput = {
  Id: "object-input-2",
  Type: "object",
  Value: {
    kind: "ref",
    ref: {
      kind: "var",
      varName: "user",
      blockPath: "001.001.001",
      path: "value", // Đảm bảo value là Object
    },
  },
};

// Tham chiếu tới CÂU TRƯỚC ĐÓ
const objectInput3: ObjectInput = {
  Id: "object-input-3",
  Type: "object",
  Value: {
    kind: "ref",
    ref: {
      kind: "question",
      blockPath: "001.001",
      path: "taken.value", // Đảm bảo value là Object
    },
  },
};

// Tham chiếu tới phần tử trong 1 Array
// objectInput4 = boughtProducts.[0]
const objectInput4: ObjectInput = {
  Id: "object-input-4",
  Type: "object",
  Value: {
    kind: "ref",
    ref: {
      kind: "var",
      varName: "boughtProducts",
      blockPath: "001.002",
      path: "value.[0].value", // [0] để truy vào con có index: 0
    },
  },
};

// 1.5/ Array Input

// Array nhập từ bàn phím.
// Dành cho INIT VARIABLE => Các thao tác khác thì chỉ được select

// Number Array
// arrayInput1 = [1, 2, 3, 4, 5, 6]
const arrayInput1: NumberArrayInput = {
  Id: "array-input-1",
  Type: "array",
  ElementType: "number",
  Value: [
    {
      Id: "array-math-input-1",
      Type: "math",
      Value: 1,
    },
    {
      Id: "array-math-input-2",
      Type: "math",
      Value: 2,
    },
    {
      Id: "array-math-input-3",
      Type: "math",
      Value: 3,
    },
    {
      Id: "array-math-input-4",
      Type: "math",
      Value: 4,
    },
    {
      Id: "array-math-input-5",
      Type: "math",
      Value: 5,
    },
    {
      Id: "array-math-input-6",
      Type: "math",
      Value: 6,
    },
  ] as MathInput[],
};

// String Array
// arrayInput2 = ["A", "B", "C", "D"]
const arrayInput2: StringArrayInput = {
  Id: "array-input-2",
  Type: "array",
  ElementType: "string",
  Value: [
    {
      Id: "array-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "A",
        placeHolders: [],
      },
    },
    {
      Id: "array-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "B",
        placeHolders: [],
      },
    },
    {
      Id: "array-string-input-3",
      Type: "string",
      Value: {
        default: "",
        template: "C",
        placeHolders: [],
      },
    },
    {
      Id: "array-string-input-4",
      Type: "string",
      Value: {
        default: "",
        template: "D",
        placeHolders: [],
      },
    },
  ] as StringInput[],
};

// Boolean Array
// arrayInput3 = [true, false, false, true]
const arrayInput3: BooleanArrayInput = {
  Id: "array-input-3",
  Type: "array",
  ElementType: "boolean",
  Value: [
    {
      Id: "array-boolean-input-1",
      Type: "boolean",
      Value: true,
    },
    {
      Id: "array-boolean-input-2",
      Type: "boolean",
      Value: false,
    },
    {
      Id: "array-boolean-input-3",
      Type: "boolean",
      Value: false,
    },
    {
      Id: "array-boolean-input-4",
      Type: "boolean",
      Value: true,
    },
  ] as BooleanInput[],
};

// ObjectArray
// arrayInput4 = [
//   {name: "User A", age: 18},
//   {name: "User B", age: 27}
// ]
const arrayInput4: ObjectArrayInput = {
  Id: "array-input-4",
  Type: "array",
  ElementType: "object",
  Value: [
    {
      Id: "array-object-input-1",
      Type: "object",
      Value: {
        name: {
          Id: "array-object-attribute-string-input-1",
          Type: "string",
          Value: {
            default: "",
            template: "User A",
            placeHolders: [],
          },
        } as StringInput,
        age: {
          Id: "array-object-attribute-math-input-1",
          Type: "math",
          Value: 18,
        } as MathInput,
      },
    },
    {
      Id: "array-object-input-2",
      Type: "object",
      Value: {
        name: {
          Id: "array-object-attribute-string-input-2",
          Type: "string",
          Value: {
            default: "",
            template: "User B",
            placeHolders: [],
          },
        } as StringInput,
        age: {
          Id: "array-object-attribute-math-input-2",
          Type: "math",
          Value: 27,
        } as MathInput,
      },
    },
  ] as ObjectInput[],
};

// Tham chiếu từ BIẾN => Mảng Object
const arrayInput5: ObjectArrayInput = {
  Id: "array-input-5",
  Type: "array",
  ElementType: "object",
  Value: {
    kind: "ref",
    ref: {
      kind: "var",
      varName: "students",
      blockPath: "001",
      path: "value",
    },
  },
};

// Tham chiếu từ CÂU TRƯỚC ĐÓ => Câu Multiple Choice
// Lấy ra danh sách tên các nhãn hàng mà khách hàng đã pick
const arrayInput6: StringArrayInput = {
  Id: "array-input-6",
  Type: "array",
  ElementType: "string",
  Value: {
    kind: "ref",
    ref: {
      kind: "question",
      blockPath: "001.001",
      path: "taken.value",
    },
  },
};

// ---------------------------------------------------------------
// ---------------------------------------------------------------
// II/ EXAMPLE CHO CÁC QUESTION INTERFACE
// ---------------------------------------------------------------
// ---------------------------------------------------------------

// RULE THAY ĐỔI CỦA CÁC QUESTION
/*
 - Tất cả các question đều cho thay đổi Content, Description
 - Single Choice:
  + Cho thay đổi CONTENT của các options bên trong, dựa vào Order để thay đổi. (Format: Options[order-number].Content)
 -  Multiple Choice:
  + Cho thay đổi CONTENT của các options bên trong, dựa vào Order để thay đổi. (Format: Options[order-number].Content)
  + Cho thay đổi MinChoiceCount, MaxChoiceCount => MathInput
 - Single Slider, Range Slider:
  + Cho thay đổi Min, Max, Step => MathInput: Thay đổi nhưng phải nhập tay chứ không lấy previous-data
  + Cho thay đổi Unit => StringInput
 - Rating:
  + Cho thay đổi RatingIcon => IconInput: Thay đổi nhưng phải select tay.
  + Cho thay đổi RatingLength => MathInput: Thay đổi nhưng phải nhập tay.
 - Ranking:
  + Cho thay đổi CONTENT của các options bên trong, dựa vào Order để thay đổi. (Format: Options[order-number].Content)
*/
// 2.1/ Single Choice Question
const singleChoiceQuestion: SingleChoiceQuestion = {
  Id: 1,
  QuestionTypeId: 1,
  Content: "Bạn có xài điện thoại Iphone không ?",
  Description: "Chọn có/không nhé!",
  Order: 1,
  IsVoiced: false,
  ConfigJson: {},
  TimeLimit: 10,
  Options: [
    {
      Id: "1-option-1",
      Content: "Có",
      Order: 1,
      Value: true,
    },
    {
      Id: "1-option-2",
      Content: "Không",
      Order: 2,
      Value: false,
    },
  ],
  // Khi khởi tạo Question sẽ mặc định Mutable là như ban đầu
  Mutable: {
    Content: {
      Id: "1-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "Bạn có xài điện thoại Iphone không ?",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "1-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "Chọn có/không nhé!",
        placeHolders: [],
      },
    } as StringInput,
    // Cho thay đổi content của các option.
    // Bao nhiêu Option thì gen ra bấy nhiêu
    // Format: Options[option-order].Content
    "Options[1].Content": {
      Id: "1-string-input-3",
      Type: "string",
      Value: {
        default: "",
        template: "Có",
        placeHolders: [],
      },
    } as StringInput,
    "Options[2].Content": {
      Id: "1-string-input-4",
      Type: "string",
      Value: {
        default: "",
        template: "Không",
        placeHolders: [],
      },
    } as StringInput,
  },
};

// 2.2/ Multiple Choice Question
const multipleChoiceQuestion: MultipleChoiceQuestion = {
  Id: 2,
  QuestionTypeId: 2,
  Content: "Bạn từng/đang xài các thương hiệu điện thoại nào",
  Description: "Chọn các loại bạn từng xài nhé!",
  Order: 2,
  IsVoiced: false,
  ConfigJson: {
    MinChoiceCount: 1,
    MaxChoiceCount: 4,
  },
  TimeLimit: 10,
  Options: [
    {
      Id: "2-option-1",
      Content: "Iphone",
      Order: 1,
      Value: "Iphone",
    },
    {
      Id: "2-option-2",
      Content: "Samsung",
      Order: 2,
      Value: "Samsung",
    },
    {
      Id: "2-option-3",
      Content: "Xiaomi",
      Order: 3,
      Value: "Xiaomo",
    },
    {
      Id: "2-option-4",
      Content: "Lenovo",
      Order: 4,
      Value: "Lenovo",
    },
  ],
  // Khi khởi tạo Question sẽ mặc định Mutable là như ban đầu
  Mutable: {
    Content: {
      Id: "2-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "Bạn từng/đang xài các thương hiệu điện thoại nào?",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "2-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "Chọn các loại bạn từng xài nhé!",
        placeHolders: [],
      },
    } as StringInput,
    "ConfigJson.MinChoiceCount": {
      Id: "2-math-input-1",
      Type: "math",
      Value: 1,
    } as MathInput,
    "ConfigJson.MaxChoiceCount": {
      Id: "2-math-input-2",
      Type: "math",
      Value: 4,
    } as MathInput,
    // Cho thay đổi content của các option.
    // Bao nhiêu Option thì gen ra bấy nhiêu
    // Format: Options[option-order].Content
    "Options[1].Content": {
      Id: "2-string-input-3",
      Type: "string",
      Value: {
        default: "",
        template: "Iphone",
        placeHolders: [],
      },
    } as StringInput,
    "Options[2].Content": {
      Id: "2-string-input-4",
      Type: "string",
      Value: {
        default: "",
        template: "Samsung",
        placeHolders: [],
      },
    } as StringInput,
    "Options[3].Content": {
      Id: "2-string-input-5",
      Type: "string",
      Value: {
        default: "",
        template: "Xiaomi",
        placeHolders: [],
      },
    } as StringInput,
    "Options[4].Content": {
      Id: "2-string-input-6",
      Type: "string",
      Value: {
        default: "",
        template: "Lenovo",
        placeHolders: [],
      },
    } as StringInput,
  },
};

// 2.3/ Single Slider Question
const singleSliderQuestion: SingleSliderQuestion = {
  Id: 3,
  QuestionTypeId: 3,
  Content:
    "Số tiền cao nhất bạn từng bỏ ra để mua 1 sản phẩm điện thoại thông minh là?",
  Description: "Kéo để chọn số tiền của bạn (VND)",
  Order: 3,
  IsVoiced: false,
  ConfigJson: {
    Min: 1000000,
    Max: 100000000,
    Step: 10000,
    Unit: "VND",
  },
  TimeLimit: 10,
  Options: [],
  Mutable: {
    Content: {
      Id: "3-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template:
          "Số tiền cao nhất bạn từng bỏ ra để mua 1 sản phẩm điện thoại thông minh là?",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "3-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "Kéo để chọn số tiền của bạn (VND)",
        placeHolders: [],
      },
    } as StringInput,
    "ConfigJson.Min": {
      Id: "3-math-input-1",
      Type: "math",
      Value: 1000000,
    } as MathInput,
    "ConfigJson.Max": {
      Id: "3-math-input-2",
      Type: "math",
      Value: 100000000,
    } as MathInput,
    "ConfigJson.Step": {
      Id: "3-math-input-3",
      Type: "math",
      Value: 100000,
    } as MathInput,
    "ConfigJson.Unit": {
      Id: "3-string-input-3",
      Type: "string",
      Value: {
        default: "",
        template: "VND",
        placeHolders: [],
      },
    } as StringInput,
  },
};

// 2.4/ Range Slider Question:
const rangeSliderQuestion: RangeSliderQuestion = {
  Id: 4,
  QuestionTypeId: 4,
  Content: "Khoảng tiền bạn sẽ bỏ ra cho 1 sản phẩm điện thoại đúng ý?",
  Description: "Kéo để chọn khoảng tiền của bạn (VND)",
  Order: 4,
  IsVoiced: false,
  ConfigJson: {
    Min: 1000000,
    Max: 100000000,
    Step: 10000,
    Unit: "VND",
  },
  TimeLimit: 10,
  Options: [],
  Mutable: {
    Content: {
      Id: "4-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "Khoảng tiền bạn sẽ bỏ ra cho 1 sản phẩm điện thoại đúng ý?",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "4-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "Kéo để chọn khoảng tiền của bạn (VND)",
        placeHolders: [],
      },
    } as StringInput,
    "ConfigJson.Min": {
      Id: "4-math-input-1",
      Type: "math",
      Value: 1000000,
    } as MathInput,
    "ConfigJson.Max": {
      Id: "4-math-input-2",
      Type: "math",
      Value: 100000000,
    } as MathInput,
    "ConfigJson.Step": {
      Id: "4-math-input-3",
      Type: "math",
      Value: 100000,
    } as MathInput,
    "ConfigJson.Unit": {
      Id: "4-string-input-3",
      Type: "string",
      Value: {
        default: "",
        template: "VND",
        placeHolders: [],
      },
    } as StringInput,
  },
};

// 2.5/ Single Input Question
const singleInputQuestion: SingleInputQuestion = {
  Id: 5,
  QuestionTypeId: 5,
  Content: "Bạn hãy nêu cảm nhận về sản phẩm của chúng tôi!",
  Description: "Viết cảm nhận của bạn xuống nhé!",
  Order: 5,
  IsVoiced: false,
  ConfigJson: {
    FieldInputTypeId: 1,
  },
  TimeLimit: 10,
  Options: [],
  Mutable: {
    Content: {
      Id: "5-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "Bạn hãy nêu cảm nhận về sản phẩm của chúng tôi!",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "5-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "Viết cảm nhận của bạn xuống nhé!",
        placeHolders: [],
      },
    } as StringInput,
  },
};

// 2.6/Rating Question
const ratingQuestion: RatingQuestion = {
  Id: 6,
  QuestionTypeId: 6,
  Content: "Trên thang điểm 10, bạn đánh giá Sản phẩm của chúng tôi bao nhiêu?",
  Description: "",
  Order: 6,
  IsVoiced: false,
  ConfigJson: {
    RatingIcon: "star",
    RatingLength: 10,
  },
  TimeLimit: 10,
  Options: [],
  Mutatble: {
    Content: {
      Id: "6-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template:
          "Trên thang điểm 10, bạn đánh giá Sản phẩm của chúng tôi bao nhiêu?",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "6-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template: "",
        placeHolders: [],
      },
    } as StringInput,
    RatingIcon: {
      Id: "6-icon-input-1",
      Type: "icon",
      IconName: "start",
    } as IconInput,
    RatingLength: {
      Id: "6-math-input-1",
      Type: "math",
      Value: 10,
    } as MathInput,
  },
};

// 2.7/Ranking Question
const rankingQuestion: RankingQuestion = {
  Id: 7,
  QuestionTypeId: 7,
  Content:
    "Xếp hạng các tiêu chí mà bạn nghĩ sẽ muốn có nhất ở một chiếc điện thoại",
  Description:
    "Nhấn vào từng lựa chọn để xếp hạng nhé! (1 là muốn nhất, 5 là ít muốn nhất)",
  Order: 7,
  IsVoiced: false,
  ConfigJson: {
    RatingIcon: "star",
    RatingLength: 10,
  },
  TimeLimit: 10,
  Options: [
    {
      Id: "7-option-1",
      Content: "Dung lượng pin lớn",
      Order: 1,
      Value: "battery",
    },
    {
      Id: "7-option-2",
      Content: "Màn hình độ phân giải cao",
      Order: 2,
      Value: "screen quality",
    },
    {
      Id: "7-option-3",
      Content: "Hệ điều hành mượt mà",
      Order: 3,
      Value: "operating system",
    },
    {
      Id: "7-option-4",
      Content: "Thiết kế đẹp",
      Order: 4,
      Value: "design",
    },
    {
      Id: "7-option-5",
      Content: "Chế độ bảo hành tốt",
      Order: 5,
      Value: "warranty",
    },
  ],
  Mutable: {
    Content: {
      Id: "7-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template:
          "Xếp hạng các tiêu chí mà bạn nghĩ sẽ muốn có nhất ở một chiếc điện thoại",
        placeHolders: [],
      },
    } as StringInput,
    Description: {
      Id: "7-string-input-2",
      Type: "string",
      Value: {
        default: "",
        template:
          "Nhấn vào từng lựa chọn để xếp hạng nhé! (1 là muốn nhất, 5 là ít muốn nhất)",
        placeHolders: [],
      },
    } as StringInput,
    "Options[1].Content": {
      Id: "7-string-input-3",
      Type: "string",
      Value: {
        default: "",
        template: "Dung lượng pin lớn",
        placeHolders: [],
      },
    } as StringInput,
    "Options[2].Content": {
      Id: "7-string-input-4",
      Type: "string",
      Value: {
        default: "",
        template: "Màn hình độ phân giải cao",
        placeHolders: [],
      },
    } as StringInput,
    "Options[3].Content": {
      Id: "7-string-input-5",
      Type: "string",
      Value: {
        default: "",
        template: "Hệ điều hành mượt mà",
        placeHolders: [],
      },
    } as StringInput,
    "Options[4].Content": {
      Id: "7-string-input-6",
      Type: "string",
      Value: {
        default: "",
        template: "Thiết kế đẹp",
        placeHolders: [],
      },
    } as StringInput,
    "Options[5].Content": {
      Id: "7-string-input-7",
      Type: "string",
      Value: {
        default: "",
        template: "Chế độ bảo hành tốt",
        placeHolders: [],
      },
    } as StringInput,
  },
};

// ---------------------------------------------------------------
// ---------------------------------------------------------------
// III/ EXAMPLE CHO CÁC BLOCK INTERFACE
// ---------------------------------------------------------------
// ---------------------------------------------------------------

// 3.1/ Start Block
const startBlock: StartBlock = {
  Id: "start-block",
  BlockTypeId: 1,
  PathId: "001", // BẮT BUỘC PHẢI LÀ 001
  ParentBlockPath: "", // BẮT BUỘC PHẢI LÀ EMPTY STRING
};

// 3.2/ End Block: Có thể có nhiều end-page-blocks render ra nhiều end-pages khác nhau
const endBlock: EndBlock = {
  Id: "end-block-1",
  BlockTypeId: 2,
  PathId: "end-1", // BẮT BUỘC CÓ PREFIX "end"
  ParentBlockPath: "", // BẮT BUỘC PHẢI LÀ EMPTY STRING
  EndPageId: 1, // Tham Chiếu Tới EndPage
};

// 3.3/ RenderQuestionBlock
// Render lại Content của Question: Chào ${user.name} trước rồi mới hỏi.
const renderQuestionBlock: RenderQuestionBlock = {
  Id: "render-question-block-1",
  BlockTypeId: 3,
  PathId: "001.001",
  ParentBlockPath: "001",
  QuestionId: 1,
  Question: {
    Id: 1,
    QuestionTypeId: 1,
    Content: "Bạn có xài điện thoại Iphone không ?",
    Description: "Chọn có/không nhé!",
    Order: 1,
    IsVoiced: false,
    ConfigJson: {},
    TimeLimit: 10,
    Options: [
      {
        Id: "1-option-1",
        Content: "Có",
        Order: 1,
        Value: true,
      },
      {
        Id: "1-option-2",
        Content: "Không",
        Order: 2,
        Value: false,
      },
    ],
    // Khi khởi tạo Question sẽ mặc định Mutable là như ban đầu
    Mutable: {
      Content: {
        Id: "1-string-input-1",
        Type: "string",
        Value: {
          default: "",
          template: "Chào ${fullName}, bạn có xài điện thoại Iphone không ?",
          placeHolders: [
            {
              name: "fullName", // Name của place holder
              dataType: "string",
              description: "Tên người dùng lấy từ biến object user",
              source: {
                kind: "ref",
                ref: {
                  kind: "var",
                  varName: "user",
                  blockPath: "001.001",
                  path: "value.name.value",
                },
              },
            },
          ],
        },
      } as StringInput,
      Description: {
        Id: "1-string-input-2",
        Type: "string",
        Value: {
          default: "",
          template: "Chọn có/không nhé!",
          placeHolders: [],
        },
      } as StringInput,
      // Cho thay đổi content của các option.
      // Bao nhiêu Option thì gen ra bấy nhiêu
      // Format: Options[option-order].Content
      "Options[1].Content": {
        Id: "1-string-input-3",
        Type: "string",
        Value: {
          default: "",
          template: "Có",
          placeHolders: [],
        },
      } as StringInput,
      "Options[2].Content": {
        Id: "1-string-input-4",
        Type: "string",
        Value: {
          default: "",
          template: "Không",
          placeHolders: [],
        },
      } as StringInput,
    },
  },
};

// 3.4/ Condition Block
// Xét điều kiện :
/*
  - Case 1:
   + Điều kiện: (user.age > 30) AND (user.income > 3000000 OR user.isRich == true)
   + Next: 001.001.001.001.001.001.001.001
  - Case 2: 
   + Điều kiện: (user.age > 30) AND !(user.income > 3000000 OR user.isRich == true)
   + Next: 001.001.001.001.001.001.001.002
  - Case 3:
   + Điều kiện: (user.age <= 30) AND (isStudyAboard == true)
   + Next: 001.001.001.001.001.001.001.003
  - Otherwise: Next: 001.001.001.001.001.001.001.004

  -- Với:
   + user: Biến lấy từ Block có path là: 001.001.001.001.001
   + isStudyAboard: Giá trị mà user đã chọn tại câu 001.001.001.001.001.001
*/
const conditionBlock: ConditionBlock = {
  Id: "condition-block-1",
  BlockTypeId: 4,
  PathId: "001.001.001.001.001.001.001",
  ParentBlockPath: "001.001.001.001.001.001",

  Cases: [
    // Case 1: (user.age > 30) AND (user.income > 3_000_000 OR user.isRich == true)
    {
      caseId: "condition-block-1-case-1",
      next: "001.001.001.001.001.001.001.001",
      condition: {
        kind: "group",
        conjunction: "AND",
        conditions: [
          // user.age > 30
          {
            kind: "atom",
            left: {
              Id: "age-ref",
              Type: "math",
              Value: {
                kind: "ref",
                ref: {
                  kind: "var",
                  varName: "user",
                  blockPath: "001.001.001.001.001",
                  path: "value.age.value",
                },
              },
            } as MathInput,
            operator: ">",
            right: {
              Id: "abc",
              Type: "math",
              Value: 30,
            } as MathInput,
          },
          // ( user.income > 3_000_000 OR user.isRich == true )
          {
            kind: "group",
            conjunction: "OR",
            conditions: [
              // user.income > 3_000_000
              {
                kind: "atom",
                left: {
                  Id: "income-ref",
                  Type: "math",
                  Value: {
                    kind: "ref",
                    ref: {
                      kind: "var",
                      varName: "user",
                      blockPath: "001.001.001.001.001",
                      path: "value.income.value",
                    },
                  },
                } as MathInput,
                operator: ">",
                right: {
                  Id: "math-input-1",
                  Type: "math",
                  Value: 3000000,
                } as MathInput,
              },
              // user.isRich == true
              {
                kind: "atom",
                left: {
                  Id: "isRich-ref",
                  Type: "boolean",
                  Value: {
                    kind: "ref",
                    ref: {
                      kind: "var",
                      varName: "user",
                      blockPath: "001.001.001.001.001",
                      path: "value.isRich.value",
                    },
                  },
                } as BooleanInput,
                operator: "== (bool)",
                right: {
                  Id: "boolean-input-1",
                  Type: "boolean",
                  Value: true,
                } as BooleanInput,
              },
            ],
          },
        ],
      },
    },

    // Case 2: (user.age > 30) AND !(user.income > 3_000_000 OR user.isRich == true)
    //  ≡ (user.age > 30) AND (user.income <= 3_000_000 AND user.isRich != true)
    {
      caseId: "condition-block-1-case-2",
      next: "001.001.001.001.001.001.001.002",
      condition: {
        kind: "group",
        conjunction: "AND",
        conditions: [
          // user.age > 30
          {
            kind: "atom",
            left: {
              Id: "age-ref",
              Type: "math",
              Value: {
                kind: "ref",
                ref: {
                  kind: "var",
                  varName: "user",
                  blockPath: "001.001.001.001.001",
                  path: "value.age.value",
                },
              },
            } as MathInput,
            operator: ">",
            right: {
              Id: "math-input-2",
              Type: "math",
              Value: 30,
            } as MathInput,
          },
          // income <= 3_000_000 AND isRich != true
          {
            kind: "group",
            conjunction: "AND",
            conditions: [
              {
                kind: "atom",
                left: {
                  Id: "income-ref",
                  Type: "math",
                  Value: {
                    kind: "ref",
                    ref: {
                      kind: "var",
                      varName: "user",
                      blockPath: "001.001.001.001.001",
                      path: "value.income.value",
                    },
                  },
                } as MathInput,
                operator: "<=",
                right: {
                  Id: "math-input-3",
                  Type: "math",
                  Value: 3000000,
                } as MathInput,
              },
              {
                kind: "atom",
                left: {
                  Id: "isRich-ref",
                  Type: "boolean",
                  Value: {
                    kind: "ref",
                    ref: {
                      kind: "var",
                      varName: "user",
                      blockPath: "001.001.001.001.001",
                      path: "isRich",
                    },
                  },
                } as BooleanInput,
                operator: "!= (bool)",
                right: {
                  Id: "boolean-input-2",
                  Type: "boolean",
                  Value: true,
                } as BooleanInput,
              },
            ],
          },
        ],
      },
    },

    // Case 3: (user.age <= 30) AND (isStudyAboard == true)
    {
      caseId: "condition-block-1-case-3",
      next: "001.001.001.001.001.001.001.003",
      condition: {
        kind: "group",
        conjunction: "AND",
        conditions: [
          // user.age <= 30
          {
            kind: "atom",
            left: {
              Id: "age-ref",
              Type: "math",
              Value: {
                kind: "ref",
                ref: {
                  kind: "var",
                  varName: "user",
                  blockPath: "001.001.001.001.001",
                  path: "value.age.value",
                },
              },
            } as MathInput,
            operator: "<=",
            right: {
              Id: "math-input-4",
              Type: "math",
              Value: 30,
            } as MathInput,
          },
          // isStudyAboard == true (từ câu 001.001.001.001.001.001)
          {
            kind: "atom",
            left: {
              Id: "isStudyAboard-ref",
              Type: "boolean",
              Value: {
                kind: "ref",
                ref: {
                  kind: "question",
                  blockPath: "001.001.001.001.001.001",
                  path: "taken.value",
                },
              },
            } as BooleanInput,
            operator: "== (bool)",
            right: {
              Id: "boolean-input-3",
              Type: "boolean",
              Value: true,
            } as BooleanInput,
          },
        ],
      },
    },
  ],

  // Otherwise
  Otherwise: "001.001.001.001.001.001.001.004",
};

// 3.5/Init Variable Block
// Init Biến Primitive Type

// Boolean
const initVariableBlock1: InitVariableBlock = {
  Id: "init-var-1",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "isMale",
    VarType: "boolean",
    DefaultValue: {
      Id: "init-var-boolean-input-1",
      Type: "boolean",
      Value: true,
    },
  },
};

// String
const initVariableBlock2: InitVariableBlock = {
  Id: "init-var-2",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "fullName",
    VarType: "string",
    DefaultValue: {
      Id: "init-var-string-input-1",
      Type: "string",
      Value: {
        default: "",
        template: "Hoàng Minh Lộc",
        placeHolders: [],
      },
    },
  },
};

// Number
const initVariableBlock3: InitVariableBlock = {
  Id: "init-var-3",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "age",
    VarType: "number",
    DefaultValue: {
      Id: "init-var-math-input-1",
      Type: "math",
      Value: 21,
    },
  },
};

// Object + Tham chiếu biến khác để init
// initVariableBlock4 = user = {name: "Hoàng Minh Lộc", age: 21, isMale: true}
const initVariableBlock4: InitVariableBlock = {
  Id: "init-var-4",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "user",
    VarType: "object",
    ObjectSchema: {
      name: "string",
      age: "number",
      isMale: "boolean",
    },
    DefaultValue: {
      Id: "init-var-object-input-1",
      Type: "object",
      Value: {
        name: {
          Id: "init-var-object-attribute-string-input-1",
          Type: "string",
          Value: {
            default: "",
            template: "${fullName}",
            placeHolders: [
              {
                name: "fullName",
                dataType: "string",
                description: "Biến FullName tham chiếu từ block init fullName",
                source: {
                  kind: "ref",
                  ref: {
                    kind: "var",
                    varName: "fullName",
                    blockPath: "001.001.001",
                    path: "value",
                  },
                },
              },
            ],
          },
        },
        age: {
          Id: "init-var-object-attribute-math-input-1",
          Type: "math",
          Value: {
            kind: "ref",
            ref: {
              kind: "var",
              varName: "age",
              blockPath: "001.001.001",
              path: "value",
            },
          },
        },
        isMale: {
          Id: "init-var-object-attribute-boolean-input-1",
          Type: "boolean",
          Value: {
            kind: "ref",
            ref: {
              kind: "var",
              varName: "isMale",
              blockPath: "001.001.001",
              path: "value",
            },
          },
        },
      },
    },
  },
};

// Array

// String Array
// initVariableBlock5 = ["Iphone", "Samsung", "Xiaomi"];
const initVariableBlock5: InitVariableBlock = {
  Id: "init-var-5",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "favoriteProducts",
    VarType: "array",
    ArrayElement: {
      type: "primitive",
      elementType: "string",
    },
    DefaultValue: {
      Id: "init-var-string-array-input-1",
      Type: "array",
      ElementType: "string",
      Value: [
        {
          Id: "init-var-string-array-string-input-1",
          Type: "string",
          Value: {
            default: "",
            template: "Iphone",
            placeHolders: [],
          },
        },
        {
          Id: "init-var-string-array-string-input-2",
          Type: "string",
          Value: {
            default: "",
            template: "Samsung",
            placeHolders: [],
          },
        },
        {
          Id: "init-var-string-array-string-input-3",
          Type: "string",
          Value: {
            default: "",
            template: "Xiaomi",
            placeHolders: [],
          },
        },
      ],
    },
  },
};

// Number Array
// initVariableBlock6 = scores = [1,2,3,4,5,6]
const initVariableBlock6: InitVariableBlock = {
  Id: "init-var-6",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "scores",
    VarType: "array",
    ArrayElement: {
      type: "primitive",
      elementType: "number",
    },
    DefaultValue: {
      Id: "init-var-number-array-input-1",
      Type: "array",
      ElementType: "number",
      Value: [
        {
          Id: "init-var-number-array-math-input-1",
          Type: "math",
          Value: 1,
        },
        {
          Id: "init-var-number-array-math-input-2",
          Type: "math",
          Value: 2,
        },
        {
          Id: "init-var-number-array-math-input-3",
          Type: "math",
          Value: 3,
        },
        {
          Id: "init-var-number-array-math-input-4",
          Type: "math",
          Value: 4,
        },
        {
          Id: "init-var-number-array-math-input-5",
          Type: "math",
          Value: 5,
        },
        {
          Id: "init-var-number-array-math-input-6",
          Type: "math",
          Value: 6,
        },
      ],
    },
  },
};

// Boolean Array
// initVariableBlock7 = takes = [true, false, true, false, false]
const initVariableBlock7: InitVariableBlock = {
  Id: "init-var-7",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "scores",
    VarType: "array",
    ArrayElement: {
      type: "primitive",
      elementType: "boolean",
    },
    DefaultValue: {
      Id: "init-var-boolean-array-input-1",
      Type: "array",
      ElementType: "boolean",
      Value: [
        {
          Id: "init-var-boolean-array-boolean-input-1",
          Type: "boolean",
          Value: true,
        },
        {
          Id: "init-var-boolean-array-boolean-input-2",
          Type: "boolean",
          Value: false,
        },
        {
          Id: "init-var-boolean-array-boolean-input-3",
          Type: "boolean",
          Value: true,
        },
        {
          Id: "init-var-boolean-array-boolean-input-4",
          Type: "boolean",
          Value: false,
        },
        {
          Id: "init-var-boolean-array-boolean-input-5",
          Type: "boolean",
          Value: false,
        },
      ],
    },
  },
};

// Object Array
// initVariableBlock 8 = [
//   {name: "User A", age: 18},
//   {name: "User B", age: 27}
// ]

const initVariableBlock8: InitVariableBlock = {
  Id: "init-var-7",
  BlockTypeId: 5,
  PathId: "001.001.001.001",
  ParentBlockPath: "001.001.001",
  Definition: {
    Name: "scores",
    VarType: "array",
    ArrayElement: {
      type: "object",
      objectSchema: {
        name: "string",
        age: "number",
      },
    },
    DefaultValue: {
      Id: "init-var-object-array-input-1",
      Type: "array",
      ElementType: "object",
      Value: [
        {
          Id: "init-var-object-array-object-input-1",
          Type: "object",
          Value: {
            name: {
              Id: "init-var-object-array-object-input-string-input-1",
              Type: "string",
              Value: {
                template: "User A",
                default: "",
                placeHolders: [],
              },
            } as StringInput,
            age: {
              Id: "init-var-object-array-object-input-math-input-1",
              Type: "math",
              Value: 18,
            } as MathInput,
          },
        },
        {
          Id: "init-var-object-array-object-input-2",
          Type: "object",
          Value: {
            name: {
              Id: "init-var-object-array-object-input-string-input-2",
              Type: "string",
              Value: {
                template: "User B",
                default: "",
                placeHolders: [],
              },
            } as StringInput,
            age: {
              Id: "init-var-object-array-object-input-math-input-2",
              Type: "math",
              Value: 27,
            } as MathInput,
          },
        },
      ],
    } as ObjectArrayInput,
  },
};

// 3.6/ Set Variable Block

// Primitive Type
const setVariableBlock1: SetVariableBlock = {
  Id: "set-var-1",
  BlockTypeId: 6,
  PathId: "001.001.001",
  ParentBlockPath: "001.001",
  Target: {
    varName: "age",
    blockPath: "001.001",
    path: "value",
  },
  Op: "replace", // Nếu là Primitive Type thì LUÔN LÀ replace
  Value: {
    Id: "set-var-math-input-1",
    Type: "math",
    Value: 20,
  } as MathInput,
};

// Object Type

// Set lại toàn bộ, đảm bảo validate các attribute. Bắt nhập tất cả các trường
const setVariableBlock2: SetVariableBlock = {
  Id: "set-var-2",
  BlockTypeId: 6,
  PathId: "001.001.001",
  ParentBlockPath: "001.001",
  Target: {
    varName: "user",
    blockPath: "001.001",
    path: "value",
  },
  Op: "replace",
  Value: {
    Id: "set-var-object-input-1",
    Type: "object",
    Value: {
      name: {
        Id: "set-var-object-attribute-string-input-1",
        Type: "string",
        Value: {
          default: "",
          template: "New User Name",
          placeHolders: [],
        },
      } as StringInput,
      age: {
        Id: "set-var-object-attribute-math-input-1",
        Type: "math",
        Value: 21,
      } as MathInput,
      isMale: {
        Id: "set-var-object-attribute-boolean-input-1",
        Type: "boolean",
        Value: false,
      } as BooleanInput,
    },
  } as ObjectInput,
};

// Set lại một số attribute nhất định thôi, không set lại toàn bộ. Không bắt nhập tất cả các trường
const setVariableBlock3: SetVariableBlock = {
  Id: "set-var-3",
  BlockTypeId: 6,
  PathId: "001.002",
  ParentBlockPath: "001",
  Target: {
    varName: "user",
    blockPath: "001.001.001.001",
    path: "value",
  },
  Op: "mergeShallow",
  Value: {
    Id: "user-age-update",
    Type: "object",
    Value: {
      age: {
        Id: "user-age-math",
        Type: "math",
        Value: 30,
      },
    },
  },
};

// Array Type

// Thêm vào đầu mảng
// VD: Mảng ở đây là mảng string => Value là 1 string input
const setVariableBlock4: SetVariableBlock = {
  Id: "set-var-4",
  BlockTypeId: 6,
  PathId: "001.002",
  ParentBlockPath: "001",
  Target: {
    varName: "favoriteProducts",
    blockPath: "001.001.001.001",
    path: "value",
  },
  Op: "unshift",
  Value: {
    Id: "set-array-string-input-1",
    Type: "string",
    Value: {
      default: "",
      template: "${selectedProduct}",
      placeHolders: [
        {
          name: "selectedProduct",
          source: {
            kind: "ref",
            ref: {
              kind: "question",
              blockPath: "001",
              path: "taken.value",
            },
          },
        },
      ],
    },
  } as StringInput,
};

// Thêm vào cuối mảng
// VD: Mảng ở đây là mảng string => Value là 1 string input
const setVariableBlock5: SetVariableBlock = {
  Id: "set-var-5",
  BlockTypeId: 6,
  PathId: "001.002",
  ParentBlockPath: "001",
  Target: {
    varName: "favoriteProducts",
    blockPath: "001.001.001.001",
    path: "value",
  },
  Op: "push",
  Value: {
    Id: "set-array-string-input-1",
    Type: "string",
    Value: {
      default: "",
      template: "${selectedProduct}",
      placeHolders: [
        {
          name: "selectedProduct",
          source: {
            kind: "ref",
            ref: {
              kind: "question",
              blockPath: "001",
              path: "taken.value",
            },
          },
        },
      ],
    },
  } as StringInput,
};

// Xóa phần tử thứ 4
const setVariableBlock6: SetVariableBlock = {
  Id: "set-var-6",
  BlockTypeId: 6,
  PathId: "001.002",
  ParentBlockPath: "001",
  Target: {
    varName: "favoriteProducts",
    blockPath: "001.001.001.001",
    path: "value",
  },
  Op: "removeAt",
  At: { index: 4 },
};

// Thêm vào vị trí thứ 3
const setVariableBlock7: SetVariableBlock = {
  Id: "set-var-7",
  BlockTypeId: 6,
  PathId: "001.002",
  ParentBlockPath: "001",
  Target: {
    varName: "favoriteProducts",
    blockPath: "001.001.001.001",
    path: "value",
  },
  Op: "setAt",
  Value: {
    Id: "set-array-string-input-1",
    Type: "string",
    Value: {
      default: "",
      template: "${selectedProduct}",
      placeHolders: [
        {
          name: "selectedProduct",
          source: {
            kind: "ref",
            ref: {
              kind: "question",
              blockPath: "001",
              path: "taken.value",
            },
          },
        },
      ],
    },
  } as StringInput,
  At: { index: 3 },
};

// 3.7/For Each Block
// Rule cho For-Each
/*
 . Giả sử pathId của Block For-Each là P = "001.001"
 - Luôn phải có attribute NextAfterLoop => Nơi tiếp theo của vòng lặp, nếu hết vòng lặp tự nhảy tới
  => NextAfterLoop = "P.001" (001.001.001)
 - Các Block con bên trong phải có prefix "loop" để phân biệt nó với các block bên ngoài
  => VD: Block con thứ nhất = "P.loop.001"
  => VD: Block con thứ hai, chạy ngay sau block con thứ nhất = "P.loop.001.001"
 - Các trường hợp kết thúc vòng lặp, chuyển sang NextAfterLoop
    + Chạy hết tất cả phần tử con bên trong.
    + Thỏa điều kiện next của 1 Condition Block con nào đó, 
      mà next trỏ tới path không có dạng "P.loop.XXX"
        => Tức là lúc này đang trỏ tới Block bên ngoài, tự break và dừng vòng lặp
    + Thỏa điều kiện next, otherwises của 1 Condition Block con nào đó, 
      mà có giá trị "___break___"
 - Các trường hợp tự nhảy sang phần tử con tiếp theo, BỎ QUA CÁC BLOCK CON DƯỚI:
    + Thỏa điều kiện next, otherwises của 1 Condition Block con nào đó, 
      mà có giá trị "___continue___"
*/

// Cho lặp và tính tổng score từ mảng scores (Number Array)
// => Nếu như trong quá trình cộng dồn mà thấy totalScore > 10
// => Tự nhảy ra ngoài tới Block Tiếp Theo

const forEachBlock1: ForEachBlock = {
  Id: "for-each-block-1",
  BlockTypeId: 7,
  PathId: "001.001.001",
  ParentBlockPath: "001.001",
  Source: {
    kind: "ref",
    ref: {
      kind: "var",
      varName: "scores",
      blockPath: "001.001",
      path: "value",
    },
  } as ArrayRefValue,
  ItemAlias: "score",
  Blocks: [
    // P.loop.001: cộng dồn
    {
      Id: "sum",
      BlockTypeId: 6,
      PathId: "001.001.001.loop.001",
      ParentBlockPath: "001.001.001",
      Target: { varName: "totalScore", blockPath: "001", path: "value" },
      Op: "replace",
      Value: {
        Id: "sum-expr",
        Type: "math",
        Value: {
          kind: "expr",
          expr: {
            node: "binary",
            op: "+",
            left: {
              node: "ref",
              ref: {
                kind: "var",
                varName: "totalScore",
                blockPath: "001",
                path: "value",
              },
            },
            right: { node: "ref", ref: { kind: "current", alias: "score" } },
          },
        },
      },
    } as SetVariableBlock,

    // P.loop.002: if totalScore > 10 → BREAK, else CONTINUE
    {
      Id: "stop-if",
      BlockTypeId: 4,
      PathId: "001.001.001.loop.002",
      ParentBlockPath: "001.001.001",
      Cases: [
        {
          caseId: "gt-10",
          condition: {
            kind: "atom",
            operator: ">",
            left: {
              Id: "t",
              Type: "math",
              Value: {
                kind: "ref",
                ref: {
                  kind: "var",
                  varName: "totalScore",
                  blockPath: "001",
                  path: "value",
                },
              },
            } as MathInput,
            right: { Id: "c10", Type: "math", Value: 10 } as MathInput,
          },
          next: "__break__", // 👈 tín hiệu break vòng lặp
        },
      ],
      Otherwise: "__continue__", // 👈 sang item kế tiếp
    } as ConditionBlock,
  ],

  NextAfterLoop: "001.001.001.001",
};
