/* ------------------------------- */
/* KHAI BÁO INTERFACE CHO BLOCKS */
/* ------------------------------- */

import type {
  AnyInput,
  ArrayInput,
  ArrayRefValue,
  BooleanArrayInput,
  BooleanInput,
  Input,
  MathInput,
  NumberArrayInput,
  ObjectArrayInput,
  ObjectInput,
  StringArrayInput,
  StringInput,
} from "./input";
import type { QuestionType } from "./question";

// Block Base Interface
export interface BlockBase {
  Id: string;
  PathId: string;
  ParentBlockPath: string;
  BlockTypeId: 1 | 2 | 3 | 4 | 5 | 6 | 7;
}

// Block Types
export type BlockType = {
  id: number;
  name: string;
};
//-----------------------------------------------//

// START BLOCK INTERFACE
export interface StartBlock extends BlockBase {
  PathId: "001";
  ParentBlockPath: "";
  BlockTypeId: 1;
}
//-----------------------------------------------//

// END BLOCK INTERFACE
export interface EndBlock extends BlockBase {
  BlockTypeId: 2;
  PathId: string;
  ParentBlockPath: "";
  EndPageId: number;
}
//-----------------------------------------------//

// RENDER QUESTION BLOCK INTERFACE
export interface RenderQuestionBlock extends BlockBase {
  BlockTypeId: 3;
  QuestionId: number;
  Question: QuestionType; //Override lại Question đó theo rule của Block
}
//-----------------------------------------------//

// CONDITION BLOCK INTERFACE
export interface ConditionBlock extends BlockBase {
  BlockTypeId: 4;
  Cases: ConditionCase[]; // nhiều case (if/else-if)
  Otherwise?: string; // pathId hoặc blockId của nhánh mặc định nếu không khớp case nào
}
export interface ConditionCase {
  caseId: string;
  condition: ConditionExpr; // thay vì mảng phẳng
  next: string; // PathId tiếp theo
}
export type ConditionExpr = ConditionAtom | ConditionGroup;

export interface ConditionAtom {
  kind: "atom";
  left: PrimaryOperand;
  operator: ConditionOperator;
  right: TargetOperand;
}
export interface ConditionGroup {
  kind: "group";
  conjunction: "AND" | "OR";
  conditions: ConditionExpr[]; // recursion
}
// Primary operand: dùng lại input types
export type PrimaryOperand =
  | StringInput
  | MathInput
  | BooleanInput
  | ArrayInput;

// Target operand: tùy theo operator và primary operand
export type TargetOperand = StringInput | MathInput | BooleanInput | ArrayInput;

export type ConditionOperator =
  // Math / Number
  | "<"
  | ">"
  | "<="
  | ">="
  | "=="
  | "!="
  // Boolean
  | "== (bool)"
  | "!= (bool)"
  // String
  | "equal to"
  | "not equal to"
  | "include"
  | "not include"
  // Array
  | "contain"
  | "not contain";
//-----------------------------------------------//

// CƠ SỞ CHO BLOCK BIẾN
export type PrimitiveType = "string" | "number" | "boolean";
export type VarType = PrimitiveType | "object" | "array";

// Object schema PHẲNG: chỉ primitive
export type FlatObjectSchema = Record<string, PrimitiveType>;

// ====== Target biến ======
export interface VarTarget {
  varName: string;
  blockPath: string;
  path?: string;
}

//-----------------------------------------------//

// INIT VAR BLOCK INTERFACE
export interface VarDefinition {
  Name: string;
  VarType: VarType;
}

export interface StringVarDefinition extends VarDefinition {
  VarType: "string";
  DefaultValue: StringInput; // ✅ đúng kiểu
}

export interface NumberVarDefinition extends VarDefinition {
  VarType: "number";
  DefaultValue: MathInput; // ✅ đúng kiểu
}

export interface BooleanVarDefinition extends VarDefinition {
  VarType: "boolean";
  DefaultValue: BooleanInput; // ✅ đúng kiểu
}

// 👇 Cho phép param hóa schema để DefaultValue buộc phải khớp
export interface ObjectVarDefinition extends VarDefinition {
  VarType: "object";
  ObjectSchema: Record<string, "string" | "number" | "boolean">;
  DefaultValue: ObjectInput;
}

export interface ArrayStringVarDefinition extends VarDefinition {
  VarType: "array";
  ArrayElement: { type: "primitive"; elementType: "string" };
  DefaultValue: StringArrayInput; // ✅ string[]
}

export interface ArrayNumberVarDefinition extends VarDefinition {
  VarType: "array";
  ArrayElement: { type: "primitive"; elementType: "number" };
  DefaultValue: NumberArrayInput; // ✅ number[]
}

export interface ArrayBooleanVarDefinition extends VarDefinition {
  VarType: "array";
  ArrayElement: { type: "primitive"; elementType: "boolean" };
  DefaultValue: BooleanArrayInput; // ✅ boolean[]
}

// 👇 Param hóa schema cho item object
export interface ArrayObjectVarDefinition extends VarDefinition {
  VarType: "array";
  ArrayElement: {
    type: "object";
    objectSchema: Record<string, "string" | "number" | "boolean">;
  };
  DefaultValue: ObjectArrayInput; // ✅ item phải khớp schema
}

// Union “chính thức” để dùng cho InitVariableBlock
export type VarDefinitionStrict =
  | StringVarDefinition
  | NumberVarDefinition
  | BooleanVarDefinition
  | ObjectVarDefinition
  | ArrayStringVarDefinition
  | ArrayNumberVarDefinition
  | ArrayBooleanVarDefinition
  | ArrayObjectVarDefinition;

export interface InitVariableBlock extends BlockBase {
  BlockTypeId: 5;
  Definition: VarDefinitionStrict; // 👈 dùng union chặt chẽ
}

//-----------------------------------------------//

// SET VAR BLOCK INTERFACE
// Toán tử khi SET
export type SetOp =
  | "replace" // thay toàn bộ giá trị đích (tại Target.path)
  | "mergeShallow" // object phẳng: ghi đè key trùng, giữ key khác
  | "push" // array: thêm cuối
  | "unshift" // array: thêm đầu
  | "setAt" // array: gán phần tử theo index
  | "removeAt"; // array: xoá phần tử theo index

export interface SetVariableBlock extends BlockBase {
  BlockTypeId: 6; // Set
  Target: VarTarget; // varName + blockPath (+ path nếu set field con)
  Op: SetOp;
  Value?: AnyInput;
  At?: { index: number };
}

// FOR EACH BLOCK INTERFACE
export interface ForEachBlock extends BlockBase {
  BlockTypeId: 7; // ví dụ 7 = for-each
  /** Nguồn mảng để lặp — chấp nhận:
   *  - ArrayRefValue (ref đến var/question),
   *  - hoặc một trong các ArrayInput cụ thể (StringArrayInput|NumberArrayInput|BooleanArrayInput|ObjectArrayInput)
   */
  Source:
    | ArrayRefValue
    | StringArrayInput
    | NumberArrayInput
    | BooleanArrayInput
    | ObjectArrayInput;

  /** Tên alias cho *phần tử item* hiện tại. Ví dụ: "score", "order", "customer" */
  ItemAlias: string;

  Blocks: any; 
  NextAfterLoop: string; // Path của Block sau khi vòng lặp diễn ra
}

export type ChildOfForEachBlock = 
RenderQuestionBlock 
| ConditionBlock 
| SetVariableBlock 
| InitVariableBlock
| ForEachBlock
