/* ------------------------------- */
/* KHAI BÁO INTERFACE CHO INPUTS */
/* ------------------------------- */

export interface CurrentRef {
  kind: "current";
  /** alias của phần tử đang lặp. Nếu bỏ trống → ngầm định dùng ForEach gần nhất */
  alias?: string;
  /** đường dẫn con trong phần tử (ví dụ "score", "qty") */
  path?: string;
  /** chọn item hay index của vòng lặp */
  select?: "item" | "index";
}

// Input Base Interface
export interface Input {
  Id: string;
  Type: "string" | "math" | "boolean" | "array" | "object" | "icon";
}

// -------------- STRING INPUT ------------------ //
export interface StringInput extends Input {
  Type: "string";
  Value: {
    default: string; // fallback cuối cùng nếu thiếu dữ liệu
    template: string; // ví dụ: "Chào ${name}, bạn ..."
    placeHolders: PlaceHolder[];
  };
}

export type PlaceholderSource = { kind: "ref"; ref: DataRef } | CurrentRef; // lấy từ block khác (var/question)

// Base cho ref (dùng lại giữa var & question)
interface DataRefBase {
  blockPath: string; // ví dụ "002.001.001"
  path: string; // ví dụ "user.value.name" hoặc "value"
}

// Tham chiếu kiểu biến
export interface DataRefVar extends DataRefBase {
  kind: "var";
  varName: string;
}

// Tham chiếu kiểu câu hỏi (bắt buộc có questionContent)
export interface DataRefQuestion extends DataRefBase {
  kind: "question";
  /** (tuỳ chọn) id riêng của câu hỏi nếu khác blockPath */
  questionId?: string;
}

// Union phân biệt
export type DataRef = DataRefVar | DataRefQuestion;

/** Mô tả placeholder */
export interface PlaceHolder {
  name: string; // ví dụ "name", "nameOfProduct"
  source: PlaceholderSource;
  dataType?: "string" | "number" | "boolean" | "date" | "any";
  required?: boolean;
  description?: string;
  fallback?: string;
  format?: string;
  transforms?: Array<{
    op: "trim" | "upper" | "lower" | "capitalize" | "custom";
    args?: Record<string, unknown>;
  }>;
}

// -------------------- MATH INPUT ------------------------ //
/** MathInput: value là 1 trong 3 dạng: literal | ref | expr */
export interface MathInput extends Input {
  Type: "math";
  Value: MathValue | Number;
  // (tùy chọn) metadata hiển thị/validate chung cho kết quả
  Meta?: {
    unit?: string; // "years", "VND", ...
    precision?: number; // số chữ số thập phân khi format
    min?: number; // ràng buộc giá trị
    max?: number;
    description?: string; // mô tả cho UI
  };
}

export type MathValue =
  | { kind: "literal"; value: number } // số nhập tay
  | { kind: "ref"; ref: NumericRef } // tham chiếu tới dữ liệu số
  | { kind: "expr"; expr: MathExpr; calculatedValue?: number }; // công thức

/** Tham chiếu số: từ biến hoặc từ dữ liệu block trước đó */
export type NumericRef =
  | { kind: "var"; varName: string; blockPath: string; path: string }
  | { kind: "question"; placeHolder: string; blockPath: string; path: string }
  | CurrentRef; // 👈 cho phép lấy số từ phần tử hiện tại (item/index)

/** AST cho biểu thức toán (an toàn, không eval string trực tiếp) */
export type MathExpr =
  | { node: "const"; value: number }
  | { node: "ref"; ref: NumericRef }
  | { node: "unary"; op: "-" | "abs" | "sqrt"; arg: MathExpr }
  | {
      node: "binary";
      op: "+" | "-" | "*" | "/" | "%" | "^";
      left: MathExpr;
      right: MathExpr;
    }
  | {
      node: "func";
      fn: "min" | "max" | "sum" | "avg" | "round" | "floor" | "ceil";
      args: MathExpr[];
      fnArgs?: { digits?: number }; // ví dụ round(digits)
    };

// -------------------- ICON INPUT ------------------------ //
export interface IconInput extends Input {
  Type: "icon";
  IconName: string;
}

// -------------------- BOOLEAN INPUT ------------------------ //
export interface BooleanInput extends Input {
  Type: "boolean";
  Value: BooleanRefValue | boolean;
}

export type BooleanRefValue = { kind: "ref"; ref: BooleanRefMap }; // tham chiếu tới dữ liệu số

export interface BooleanVarRef {
  kind: "var";
  varName: string;
  blockPath: string;
  path: string;
}
export interface BooleanPreviousDataRef {
  kind: "question";
  blockPath: string;
  path: string;
}
export type BooleanRefMap = BooleanVarRef | BooleanPreviousDataRef | CurrentRef; // 👈 cho phép đọc boolean từ item hiện tại;

// -------------------- ARRAY INPUT ------------------------ //

export interface ArrayInput extends Input {
  Type: "array";
  ElementType: "string" | "number" | "boolean" | "object";
}

export interface StringArrayInput extends ArrayInput {
  ElementType: "string";
  Value: ArrayRefValue | StringInput[];
}

export interface NumberArrayInput extends ArrayInput {
  ElementType: "number";
  Value: ArrayRefValue | MathInput[];
}

export interface BooleanArrayInput extends ArrayInput {
  ElementType: "boolean";
  Value: ArrayRefValue | BooleanInput[];
}

export interface ObjectArrayInput extends ArrayInput {
  ElementType: "object";
  Value: ArrayRefValue | ObjectInput[];
}

export type ArrayRefValue = {
  kind: "ref";
  ref: ArrayRefMap;
};

export type ArrayRefMap = ArrayVarRef | ArrayPreviousQuestionRef;
export interface ArrayVarRef {
  kind: "var";
  varName: string;
  blockPath: string;
  path: string;
}
export interface ArrayPreviousQuestionRef {
  kind: "question";
  blockPath: string;
  path: string;
}

// -------------------- OBJECT INPUT ------------------------ //
// Gom các input sẵn có
export type AnyScalarInput = StringInput | MathInput | BooleanInput; // giá trị vô cùng (string/number/boolean)
export type AnyCollectionInput = ArrayInput | ObjectInput;
export type AnyInput = AnyScalarInput | AnyCollectionInput;
// Mode 1: Fields mode (mỗi field là scalar input)
// Mode 2: Ref mode (ref -> object) + pick/map để phẳng hoá
export interface ObjectInput extends Input {
  Type: "object";
  Value: ObjectFieldsValue | ObjectRefValue;
}

// --- Mode 1: fields ---
export type ObjectFieldsValue = Record<string, AnyScalarInput>;

// --- Mode 2: ref ---
export interface ObjectRefValue {
  kind: "ref";
  ref: ObjectRefSource;
  /** (optional) Chỉ lấy các key này, giữ nguyên tên key (áp dụng sau khi resolve ref) */
  pick?: string[];
  /** (optional) Ánh xạ keyOut -> pathIn (pathIn có thể là "a.b.c") */
  map?: Record<string, string>;
  /** (optional) Bỏ qua key có giá trị null/undefined sau khi resolve (mặc định false) */
  compact?: boolean;
}

/** Nguồn ref cho object: từ biến, từ câu hỏi, hoặc từ current item của for-each */
export type ObjectRefSource = ObjectVarRef | ObjectPreviousRef | CurrentRef;

export interface ObjectVarRef {
  kind: "var";
  varName: string;
  blockPath: string; // PathId của block đang quản lý biến
  path: string; // vd: "Value" hoặc "Value.profile"
}

export interface ObjectPreviousRef {
  kind: "question";
  blockPath: string; // PathId của block hỏi trước
  path: string; // vd: "taken.payload"
}
